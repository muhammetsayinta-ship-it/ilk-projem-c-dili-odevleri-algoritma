//1’den 100’e kadar olan sayıların toplamını ekrana yazdır (FOR ile).
#include <stdio.h>

int main() {
    int i, toplam = 0;

    for(i = 1; i <= 100; i++) {
        toplam += i;
    }

    printf("Toplam: %d", toplam);

    return 0;
}
