/*
Kullanıcıdan maaş al.
Maaş 10.000’den büyükse → %10 zam
Maaş 10.000 veya daha az ise → %20 zam
Yeni maaşı ekrana yazdır.
*/
#include <stdio.h>

int main() {
    float maas;

    printf("Maas gir: ");
    scanf("%f", &maas);

    if(maas > 10000)
        maas = maas * 1.10;
    else
        maas = maas * 1.20;

    printf("Yeni maas: %.2f", maas);

    return 0;
}
