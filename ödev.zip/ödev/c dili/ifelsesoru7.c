//Kullanıcıdan şifre al. Şifre 1234 ise “Giriş başarılı”, değilse “Hatalı şifre” yazdır.
#include <stdio.h>

int main() {
    int sifre;

    printf("Sifre gir: ");
    scanf("%d", &sifre);

    if(sifre == 1234)
        printf("Giris Basarili");
    else
        printf("Hatali sifre");

    return 0;
}
