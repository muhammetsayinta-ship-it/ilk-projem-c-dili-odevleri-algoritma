/*
Kullanıcıdan bir karakter al.
Harf ise: “Harf”
Rakam ise: “Rakam”
Diğer karakter ise: “Diğer karakter”
*/
#include <stdio.h>

int main() {
    char c;

    printf("Bir karakter gir: ");
    scanf(" %c", &c);   // boşluk bırakmak önemli: klavye tamponunu temizler

    if(c >= '0' && c <= '9')
        printf("Rakam");
    else if((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
        printf("Harf");
    else
        printf("Diger karakter");

    return 0;
}
