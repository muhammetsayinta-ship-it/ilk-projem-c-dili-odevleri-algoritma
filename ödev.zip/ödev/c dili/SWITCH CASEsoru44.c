//Kullanıcıdan bir harf al. Harf sesli ise “Sesli harf”, değilse “Sessiz harf” yazdır (a, e, i, o, u).
#include <stdio.h>

int main() {
    char harf;

    printf("Bir harf gir: ");
    scanf(" %c", &harf);

    switch(harf) {
        case 'a': case 'e': case 'i': case 'o': case 'u':
        case 'A': case 'E': case 'I': case 'O': case 'U':
            printf("Sesli harf");
            break;
        default:
            printf("Sessiz harf");
    }

    return 0;
}
