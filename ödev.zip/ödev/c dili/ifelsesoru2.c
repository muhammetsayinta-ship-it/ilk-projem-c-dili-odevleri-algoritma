//Kullanıcıdan yaş al. 18 ve üzeriyse “Reşit”, değilse “Reşit değil” yazdır.
#include <stdio.h>

int main() {
    int yas;

    printf("Yas gir: ");
    scanf("%d", &yas);

    if(yas >= 18)
        printf("Resit");
    else
        printf("Resit degil");

    return 0;
}
