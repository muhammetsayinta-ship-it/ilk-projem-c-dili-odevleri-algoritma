//Kullanıcıdan5 sayıal ve toplamını ekrana yazdır (WHILE ile).
#include <stdio.h>

int main() {
    int sayi, toplam = 0, i = 0;

    while(i < 5) {
        printf("Sayi gir: ");
        scanf("%d", &sayi);
        toplam += sayi;
        i++;
    }

    printf("Toplam: %d", toplam);

    return 0;
}
