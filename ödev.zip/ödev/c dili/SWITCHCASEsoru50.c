/*
Kullanıcıdan bir sayı al (1–5).
1 → “Elma”
2 → “Armut”
3 → “Muz”
4 → “Kiraz”
5 → “Çilek”
Diğer → “Geçersiz meyve”
*/
#include <stdio.h>

int main() {
    int secim;

    printf("Meyve sec (1=Elma, 2=Armut, 3=Muz, 4=Kiraz, 5=Cilek): ");
    scanf("%d", &secim);

    switch(secim) {
        case 1: printf("Elma"); break;
        case 2: printf("Armut"); break;
        case 3: printf("Muz"); break;
        case 4: printf("Kiraz"); break;
        case 5: printf("Cilek"); break;
        default: printf("Gecersiz meyve");
    }

    return 0;
}
