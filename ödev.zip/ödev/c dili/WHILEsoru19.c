//Kullanıcıdan sayılar al. Kullanıcı -1 girene kadar girilen sayıların toplamını ekrana yazdır (WHILE ile).
#include <stdio.h>

int main() {
    int sayi, toplam = 0;

    printf("Sayi gir (-1 girince duracak): ");
    scanf("%d", &sayi);

    while(sayi != -1) {
        toplam += sayi;
        printf("Sayi gir (-1 girince duracak): ");
        scanf("%d", &sayi);
    }

    printf("Toplam: %d", toplam);

    return 0;
}
