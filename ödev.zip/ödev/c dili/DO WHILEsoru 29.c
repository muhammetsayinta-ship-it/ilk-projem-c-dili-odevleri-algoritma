//Kullanıcıdan sayılar al. Kullanıcı -1 girene kadar girilen sayıların toplamını ekrana yazdır (DO–WHILE ile).
#include <stdio.h>

int main() {
    int sayi, toplam = 0;

    do {
        printf("Sayi gir (-1 girince duracak): ");
        scanf("%d", &sayi);
        if(sayi != -1)
            toplam += sayi;
    } while(sayi != -1);

    printf("Toplam: %d", toplam);

    return 0;
}
