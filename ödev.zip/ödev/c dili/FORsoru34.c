//Kullanıcıdan 5 sayı al ve toplamını ekrana yazdır (FOR ile).
#include <stdio.h>

int main() {
    int i, sayi, toplam = 0;

    for(i = 0; i < 5; i++) {
        printf("Sayi gir: ");
        scanf("%d", &sayi);
        toplam += sayi;
    }

    printf("Toplam: %d", toplam);

    return 0;
}
