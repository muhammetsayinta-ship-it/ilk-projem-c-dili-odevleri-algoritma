/*
Kullanıcıdan bir sayı al (1–4).
1 → “Kirmizi”
2 → “Mavi”
3 → “Yesil”
4 → “Sari”
Diğer sayılar → “Gecersiz renk”
*/
#include <stdio.h>

int main() {
    int secim;

    printf("Renk sec (1=Kirmizi, 2=Mavi, 3=Yesil, 4=Sari): ");
    scanf("%d", &secim);

    switch(secim) {
        case 1: printf("Kirmizi"); break;
        case 2: printf("Mavi"); break;
        case 3: printf("Yesil"); break;
        case 4: printf("Sari"); break;
        default: printf("Gecersiz renk");
    }

    return 0;
}
