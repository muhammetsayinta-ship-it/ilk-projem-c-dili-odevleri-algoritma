//Kullanıcıdan 1’den 50’ye kadar olan sayıların sadece 5’e bölünenlerini ekrana yazdır (FOR ile).
#include <stdio.h>

int main() {
    int i;

    for(i = 1; i <= 50; i++) {
        if(i % 5 == 0)
            printf("%d\n", i);
    }

    return 0;
}
