//Kullanıcıdan 1–7 arasında bir sayı al ve karşılığını hafta günü olarak yazdır (1 = Pazartesi, 7 = Pazar).
#include <stdio.h>

int main() {
    int gun;

    printf("1-7 arasi gun sayisi gir: ");
    scanf("%d", &gun);

    switch(gun) {
        case 1: printf("Pazartesi"); break;
        case 2: printf("Sali"); break;
        case 3: printf("Carsamba"); break;
        case 4: printf("Persembe"); break;
        case 5: printf("Cuma"); break;
        case 6: printf("Cumartesi"); break;
        case 7: printf("Pazar"); break;
        default: printf("Gecersiz sayi");
    }

    return 0;
}
