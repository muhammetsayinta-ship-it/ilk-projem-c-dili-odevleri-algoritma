//Kullanıcıdan pozitif bir sayı al ve 1’den başlayarak bu sayıya kadar olan tüm sayıların faktöriyelini ekrana yazdır (DO–WHILE ile).
#include <stdio.h>

int main() {
    int n, i = 1;
    long fakt;

    printf("Pozitif sayi gir: ");
    scanf("%d", &n);

    do {
        fakt = 1;
        int j = 1;
        do {
            fakt *= j;
            j++;
        } while(j <= i);
        printf("%d! = %ld\n", i, fakt);
        i++;
    } while(i <= n);

    return 0;
}
