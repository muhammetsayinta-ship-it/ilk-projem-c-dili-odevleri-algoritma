/*
Kullanıcıdan bir sayı al (1–4) ve ona göre basit matematik işlemi uygula:
1 → sayıyı 2 ile çarp
2 → sayıyı 5 ile böl
3 → sayıyı 3 ile topla
4 → sayıyı 4 ile çıkar
Diğer → “Geçersiz seçim”
*/
#include <stdio.h>

int main() {
    int secim;
    float sayi;

    printf("Sayi gir: ");
    scanf("%f", &sayi);

    printf("Islem sec (1=Carp2, 2=Bol5, 3=Topla3, 4=Cikar4): ");
    scanf("%d", &secim);

    switch(secim) {
        case 1: printf("Sonuc: %.2f", sayi * 2); break;
        case 2: printf("Sonuc: %.2f", sayi / 5); break;
        case 3: printf("Sonuc: %.2f", sayi + 3); break;
        case 4: printf("Sonuc: %.2f", sayi - 4); break;
        default: printf("Gecersiz secim");
    }

    return 0;
}
