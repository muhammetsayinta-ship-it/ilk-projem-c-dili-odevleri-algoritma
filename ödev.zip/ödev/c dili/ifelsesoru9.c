//Kullanıcıdan sayı al. Sayı 100 ile 200 arasında ise “Aralıkta”, değilse “Aralık dışı” yazdır.
#include <stdio.h>

int main() {
    int x;

    printf("Sayi gir: ");
    scanf("%d", &x);

    if(x >= 100 && x <= 200)
        printf("Aralikta");
    else
        printf("Aralik disi");

    return 0;
}
