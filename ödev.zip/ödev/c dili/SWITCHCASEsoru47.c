/*
Kullanıcıdan bir sayı al (1–4).

1 → “Kış”

2 → “İlkbahar”
3 → “Yaz”
4 → “Sonbahar”
Diğer sayılar → “Geçersiz mevsim”
*/
#include <stdio.h>

int main() {
    int secim;

    printf("Mevsim sec (1=Kis, 2=Ilkbahar, 3=Yaz, 4=Sonbahar): ");
    scanf("%d", &secim);

    switch(secim) {
        case 1: printf("Kis"); break;
        case 2: printf("Ilkbahar"); break;
        case 3: printf("Yaz"); break;
        case 4: printf("Sonbahar"); break;
        default: printf("Gecersiz mevsim");
    }

    return 0;
}
