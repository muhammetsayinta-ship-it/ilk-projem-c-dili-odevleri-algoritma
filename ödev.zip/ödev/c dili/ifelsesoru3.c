//Kullanıcıdan bir tam sayı al. Sayı çiftse “Çift”, tekse “Tek” yazdır.
#include <stdio.h>

int main() {
    int s;

    printf("Sayi gir: ");
    scanf("%d", &s);

    if(s % 2 == 0)
        printf("Cift");
    else
        printf("Tek");

    return 0;
}
