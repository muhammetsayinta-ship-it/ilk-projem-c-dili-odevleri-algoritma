//Kullanıcıdan bir sayı al. Sayı pozitifse “Pozitif”, negatifse “Negatif”, sıfırsa “Sıfır” yazdır.
#include <stdio.h>

int main() {
    int x;

    printf("Sayi gir: ");
    scanf("%d", &x);

    if(x > 0)
        printf("Pozitif");
    else if(x < 0)
        printf("Negatif");
    else
        printf("Sifir");

    return 0;
}
