//1’den 50’ye kadar olan çift sayıları ekrana yazdır (FOR ile).
#include <stdio.h>

int main() {
    int i;

    for(i = 2; i <= 50; i += 2) {
        printf("%d\n", i);
    }

    return 0;
}
