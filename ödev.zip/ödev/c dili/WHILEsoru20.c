//1’den 100’e kadar olan tüm tek sayıları ekrana yazdır (WHILE ile).
#include <stdio.h>

int main() {
    int i = 1;

    while(i <= 100) {
        printf("%d\n", i);
        i += 2;  // sadece tek sayılar
    }

    return 0;
}
