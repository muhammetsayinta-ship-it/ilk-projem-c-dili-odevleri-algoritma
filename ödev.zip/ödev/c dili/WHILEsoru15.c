/*
Kullanıcıdan 10’dan küçük sayılar al, toplamını ekrana yazdır (WHILE ile).
Kullanıcı 10 veya daha büyük bir sayı girerse döngü bitsin.
*/
#include <stdio.h>

int main() {
    int sayi, toplam = 0;

    printf("Sayi gir (10 veya ustu girince duracak): ");
    scanf("%d", &sayi);

    while(sayi < 10) {
        toplam += sayi;
        printf("Sayi gir (10 veya ustu girince duracak): ");
        scanf("%d", &sayi);
    }

    printf("Toplam: %d", toplam);

    return 0;
}
