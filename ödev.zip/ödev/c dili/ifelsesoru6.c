/*
Kullanıcıdan sıcaklık değeri al.

0'ın altındaysa → “Soğuk”
0 ile 30 arasındaysa → “Normal”
30'un üstündeyse → “Sıcak”
*/
#include <stdio.h>

int main() {
    int t;

    printf("Sicaklik: ");
    scanf("%d", &t);

    if(t < 0)
        printf("Soguk");
    else if(t <= 30)
        printf("Normal");
    else
        printf("Sicak");

    return 0;
}
