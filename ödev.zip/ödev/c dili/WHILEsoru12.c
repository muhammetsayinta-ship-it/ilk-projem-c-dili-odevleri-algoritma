//1’den başlayarak 10’a kadar olan sayıları ekrana yazdır (WHILE ile).
#include <stdio.h>

int main() {
    int i = 1;

    while(i <= 10) {
        printf("%d\n", i);
        i++;
    }

    return 0;
}
