/*
Kullanıcıdan işlem seçmesini iste: 1 = Toplama, 2 = Çıkarma, 3 = Çarpma, 4 = Bölme. Ardından iki sayı al ve seçilen işlemi uygula.
*/
#include <stdio.h>

int main() {
    int secim;
    float a, b;

    printf("Islem sec (1=Toplama, 2=Cikarma, 3=Carpma, 4=Bolme): ");
    scanf("%d", &secim);

    printf("Iki sayi gir: ");
    scanf("%f %f", &a, &b);

    switch(secim) {
        case 1: printf("Toplam: %.2f", a + b); break;
        case 2: printf("Cikarma: %.2f", a - b); break;
        case 3: printf("Carpma: %.2f", a * b); break;
        case 4: 
            if(b != 0)
                printf("Bolme: %.2f", a / b);
            else
                printf("Sifira bolme hatasi");
            break;
        default: printf("Gecersiz secim");
    }

    return 0;
}
