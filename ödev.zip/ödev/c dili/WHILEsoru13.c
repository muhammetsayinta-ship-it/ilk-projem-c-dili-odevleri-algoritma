/*
Kullanıcıdan negatif bir sayı girene kadar sayı almaya devam et, girilen sayıların toplamını ekrana yazdır (WHILE ile).
*/
#include <stdio.h>

int main() {
    int sayi, toplam = 0;

    printf("Sayi gir (Negatif girince duracak): ");
    scanf("%d", &sayi);

    while(sayi >= 0) {
        toplam += sayi;
        printf("Sayi gir (Negatif girince duracak): ");
        scanf("%d", &sayi);
    }

    printf("Toplam: %d", toplam);

    return 0;
}
