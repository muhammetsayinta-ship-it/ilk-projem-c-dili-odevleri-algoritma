//Kullanıcıdan bir sayı al ve 1’den o sayıya kadar olan sayıların faktöriyelini ekrana yazdır (FOR ile).
#include <stdio.h>

int main() {
    int n, i, j;
    long fakt;

    printf("Pozitif sayi gir: ");
    scanf("%d", &n);

    for(i = 1; i <= n; i++) {
        fakt = 1;
        for(j = 1; j <= i; j++) {
            fakt *= j;
        }
        printf("%d! = %ld\n", i, fakt);
    }

    return 0;
}
