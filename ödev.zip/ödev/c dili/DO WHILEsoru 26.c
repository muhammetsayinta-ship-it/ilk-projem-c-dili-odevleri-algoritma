//1’den 100’e kadar olan sayıların toplamını ekrana yazdır (DO–WHILE ile).
#include <stdio.h>

int main() {
    int i = 1, toplam = 0;

    do {
        toplam += i;
        i++;
    } while(i <= 100);

    printf("Toplam: %d", toplam);

    return 0;
}
