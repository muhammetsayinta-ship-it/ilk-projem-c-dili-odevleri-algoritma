/*
Kullanıcıdan bir sayı al (1–3).
1 → “Kahve”
2 → “Çay”
3 → “Su”
Diğer → “Geçersiz içecek”
*/
#include <stdio.h>

int main() {
    int secim;

    printf("Icek sec (1=Kahve, 2=Cay, 3=Su): ");
    scanf("%d", &secim);

    switch(secim) {
        case 1: printf("Kahve"); break;
        case 2: printf("Cay"); break;
        case 3: printf("Su"); break;
        default: printf("Gecersiz icecek");
    }

    return 0;
}
