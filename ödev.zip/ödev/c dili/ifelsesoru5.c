//Kullanıcıdan 3 sayı al. Bu üç sayıdan en büyüğünü ekrana yazdır.
#include <stdio.h>

int main() {
    int a, b, c;

    printf("3 sayi gir: ");
    scanf("%d %d %d", &a, &b, &c);

    if(a >= b && a >= c)
        printf("En buyuk: %d", a);
    else if(b >= a && b >= c)
        printf("En buyuk: %d", b);
    else
        printf("En buyuk: %d", c);

    return 0;
}
