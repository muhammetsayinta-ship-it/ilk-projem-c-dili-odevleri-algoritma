//Kullanıcıdan 5 sayı al ve toplamını ekrana yazdır (DO–WHILE ile).
#include <stdio.h>

int main() {
    int sayi, toplam = 0, i = 0;

    do {
        printf("Sayi gir: ");
        scanf("%d", &sayi);
        toplam += sayi;
        i++;
    } while(i < 5);

    printf("Toplam: %d", toplam);

    return 0;
}
