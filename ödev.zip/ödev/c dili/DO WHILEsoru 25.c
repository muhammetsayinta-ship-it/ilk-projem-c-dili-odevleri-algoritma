/*
Kullanıcıdan 10’dan küçük sayılar al, toplamını ekrana yazdır (DO–WHILE ile).
Kullanıcı 10 veya daha büyük bir sayı girerse döngü bitsin.
*/
#include <stdio.h>

int main() {
    int sayi, toplam = 0;

    do {
        printf("Sayi gir (10 veya ustu girince duracak): ");
        scanf("%d", &sayi);
        if(sayi < 10)
            toplam += sayi;
    } while(sayi < 10);

    printf("Toplam: %d", toplam);

    return 0;
}
