//1’den 100’e kadar olan sayıların toplamını ekrana yazdır (WHILE ile).
#include <stdio.h>

int main() {
    int i = 1, toplam = 0;

    while(i <= 100) {
        toplam += i;
        i++;
    }

    printf("Toplam: %d", toplam);

    return 0;
}
