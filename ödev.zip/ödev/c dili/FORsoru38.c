//Kullanıcıdan 10 sayı al ve çift sayıların toplamını ekrana yazdır (FOR ile).
#include <stdio.h>

int main() {
    int i, sayi, toplam = 0;

    for(i = 0; i < 10; i++) {
        printf("Sayi gir: ");
        scanf("%d", &sayi);
        if(sayi % 2 == 0)
            toplam += sayi;
    }

    printf("Cift sayilarin toplami: %d", toplam);

    return 0;
}
