//Kullanıcıdan 1–12 arasında bir sayı al ve karşılığını ay adı olarak yazdır (1 = Ocak, 12 = Aralık).
#include <stdio.h>

int main() {
    int ay;

    printf("1-12 arasi ay sayisi gir: ");
    scanf("%d", &ay);

    switch(ay) {
        case 1: printf("Ocak"); break;
        case 2: printf("Subat"); break;
        case 3: printf("Mart"); break;
        case 4: printf("Nisan"); break;
        case 5: printf("Mayis"); break;
        case 6: printf("Haziran"); break;
        case 7: printf("Temmuz"); break;
        case 8: printf("Agustos"); break;
        case 9: printf("Eylul"); break;
        case 10: printf("Ekim"); break;
        case 11: printf("Kasim"); break;
        case 12: printf("Aralik"); break;
        default: printf("Gecersiz sayi");
    }

    return 0;
}
