/*Kullanıcıdan bir not al (0–100).
Not 50 ve üzeriyse “Geçtin”, 50’nin altındaysa “Kaldın” yazdır. */
#include <stdio.h>

int main() {
    int not;

    printf("Not gir: ");
    scanf("%d", &not);

    if(not >= 50)
        printf("Gectin");
    else
        printf("Kaldin");

    return 0;
}
