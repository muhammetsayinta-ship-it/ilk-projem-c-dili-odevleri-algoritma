//Kullanıcıdan 1’den 10’a kadar olan sayıların karesini al ve ekrana yazdır (FOR ile).
#include <stdio.h>

int main() {
    int i;

    for(i = 1; i <= 10; i++) {
        printf("%d^2 = %d\n", i, i * i);
    }

    return 0;
}
