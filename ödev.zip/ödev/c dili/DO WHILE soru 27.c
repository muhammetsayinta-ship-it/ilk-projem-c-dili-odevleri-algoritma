//Kullanıcıdan sayı al. Girilen sayı sıfır olana kadar sayıların karesini ekrana yazdır (DO–WHILE ile).
#include <stdio.h>

int main() {
    int sayi;

    do {
        printf("Sayi gir (0 girince duracak): ");
        scanf("%d", &sayi);
        if(sayi != 0)
            printf("Karesi: %d\n", sayi * sayi);
    } while(sayi != 0);

    return 0;
}
