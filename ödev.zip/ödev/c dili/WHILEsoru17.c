//Kullanıcıdan sayı al. Girilen sayı sıfır olana kadar sayıların karesini ekrana yazdır (WHILE ile).
#include <stdio.h>

int main() {
    int sayi;

    printf("Sayi gir (0 girince duracak): ");
    scanf("%d", &sayi);

    while(sayi != 0) {
        printf("Karesi: %d\n", sayi * sayi);
        printf("Sayi gir (0 girince duracak): ");
        scanf("%d", &sayi);
    }

    return 0;
}
