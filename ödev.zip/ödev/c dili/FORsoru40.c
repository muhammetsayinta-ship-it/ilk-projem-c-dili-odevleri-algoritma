//Kullanıcıdan 10 sayı al ve en büyük sayıyı ekrana yazdır (FOR ile).
#include <stdio.h>

int main() {
    int i, sayi, enBuyuk;

    printf("Sayi gir: ");
    scanf("%d", &enBuyuk);  // ilk sayıyı enBuyuk olarak al

    for(i = 1; i < 10; i++) {
        printf("Sayi gir: ");
        scanf("%d", &sayi);
        if(sayi > enBuyuk)
            enBuyuk = sayi;
    }

    printf("En buyuk sayi: %d", enBuyuk);

    return 0;
}
