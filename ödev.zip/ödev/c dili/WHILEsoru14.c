//1’den 50’ye kadar olan çift sayıları ekrana yazdır (WHILE ile).
#include <stdio.h>

int main() {
    int i = 2;

    while(i <= 50) {
        printf("%d\n", i);
        i += 2;  // sadece çift sayıları al
    }

    return 0;
}
