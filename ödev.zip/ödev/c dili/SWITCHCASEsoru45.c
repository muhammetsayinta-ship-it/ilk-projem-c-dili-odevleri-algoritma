/*
Kullanıcıdan not al (0–100).

90–100 → A

80–89 → B

70–79 → C

60–69 → D
0–59 → F
Switch–case ile harfi yazdır.
*/
#include <stdio.h>

int main() {
    int notDegeri;
    char harf;

    printf("Not gir (0-100): ");
    scanf("%d", &notDegeri);

    switch(notDegeri / 10) {
        case 10:
        case 9: harf = 'A'; break;
        case 8: harf = 'B'; break;
        case 7: harf = 'C'; break;
        case 6: harf = 'D'; break;
        default: harf = 'F';
    }

    printf("Harf notu: %c", harf);

    return 0;
}

