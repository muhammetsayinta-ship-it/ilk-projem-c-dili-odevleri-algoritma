//1’den 50’ye kadar olan çift sayıları ekrana yazdır (DO–WHILE ile).
#include <stdio.h>

int main() {
    int i = 2;

    do {
        printf("%d\n", i);
        i += 2;  // sadece çift sayılar
    } while(i <= 50);

    return 0;
}
