//Kullanıcıdan pozitif bir sayı al ve 1’den başlayarak bu sayıya kadar olan tüm sayıların faktöriyelini ekrana yazdır (WHILE ile).
#include <stdio.h>

int main() {
    int n, i = 1;
    long fakt = 1;

    printf("Pozitif sayi gir: ");
    scanf("%d", &n);

    while(i <= n) {
        fakt = 1;
        int j = 1;
        while(j <= i) {
            fakt *= j;
            j++;
        }
        printf("%d! = %ld\n", i, fakt);
        i++;
    }

    return 0;
}
