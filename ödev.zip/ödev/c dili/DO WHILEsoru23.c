//Kullanıcıdan negatif bir sayı girene kadar sayı almaya devam et, girilen sayıların toplamını ekrana yazdır (DO–WHILE ile).
#include <stdio.h>

int main() {
    int sayi, toplam = 0;

    do {
        printf("Sayi gir (Negatif girince duracak): ");
        scanf("%d", &sayi);
        if(sayi >= 0)
            toplam += sayi;
    } while(sayi >= 0);

    printf("Toplam: %d", toplam);

    return 0;
}
